return {
  -- Install the VS Code theme plugin
  {
    "Mofiqul/vscode.nvim",
    lazy = false,
    priority = 1000,
    opts = {
      -- You can choose 'dark' or 'light'
      style = "dark",
      -- Optional: enable transparency if you want
      transparent = false,
      italic_comments = true,
    },
  },

  -- Configure LazyVim to use it as the main colorscheme
  {
    "LazyVim/LazyVim",
    opts = {
      colorscheme = "vscode",
    },
  },
}
